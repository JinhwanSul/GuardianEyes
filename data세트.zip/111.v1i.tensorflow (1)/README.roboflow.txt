
111 - v1 2021-11-04 1:38am
==============================

This dataset was exported via roboflow.ai on November 3, 2021 at 4:39 PM GMT

It includes 275 images.
Object are annotated in Tensorflow Object Detection format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip


